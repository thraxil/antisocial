================================
The PIL.McIdasImagePlugin Module
================================

The PIL.McIdasImagePlugin Module
================================

**McIdasImageFile** (class)
[`# <#PIL.McIdasImagePlugin.McIdasImageFile-class>`_]
    Image plugin for McIdas area images.

    For more information about this class, see `*The McIdasImageFile
    Class* <#PIL.McIdasImagePlugin.McIdasImageFile-class>`_.

The McIdasImageFile Class
-------------------------

**McIdasImageFile** (class)
[`# <#PIL.McIdasImagePlugin.McIdasImageFile-class>`_]
