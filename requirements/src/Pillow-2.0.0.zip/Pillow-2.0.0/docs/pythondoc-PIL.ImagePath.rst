========================
The PIL.ImagePath Module
========================

The PIL.ImagePath Module
========================

**Path(xy)** (class) [`# <#PIL.ImagePath.Path-class>`_]
    Path wrapper.

    For more information about this class, see `*The Path
    Class* <#PIL.ImagePath.Path-class>`_.

The Path Class
--------------

**Path(xy)** (class) [`# <#PIL.ImagePath.Path-class>`_]
**\_\_init\_\_(xy)** [`# <#PIL.ImagePath.Path.__init__-method>`_]

    *xy*

**compact(distance=2)** [`# <#PIL.ImagePath.Path.compact-method>`_]
**getbbox()** [`# <#PIL.ImagePath.Path.getbbox-method>`_]
**map(function)** [`# <#PIL.ImagePath.Path.map-method>`_]
**tolist(flat=0)** [`# <#PIL.ImagePath.Path.tolist-method>`_]

    *flat*
    Returns:

**transform(matrix)** [`# <#PIL.ImagePath.Path.transform-method>`_]
