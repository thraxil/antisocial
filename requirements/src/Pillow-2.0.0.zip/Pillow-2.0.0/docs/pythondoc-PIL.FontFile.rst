=======================
The PIL.FontFile Module
=======================

The PIL.FontFile Module
=======================

**FontFile()** (class) [`# <#PIL.FontFile.FontFile-class>`_]
    Base class for raster font file handlers.

    For more information about this class, see `*The FontFile
    Class* <#PIL.FontFile.FontFile-class>`_.

The FontFile Class
------------------

**FontFile()** (class) [`# <#PIL.FontFile.FontFile-class>`_]
