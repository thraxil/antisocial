=============================
The PIL.PcdImagePlugin Module
=============================

The PIL.PcdImagePlugin Module
=============================

**PcdImageFile** (class) [`# <#PIL.PcdImagePlugin.PcdImageFile-class>`_]
    Image plugin for PhotoCD images.

    For more information about this class, see `*The PcdImageFile
    Class* <#PIL.PcdImagePlugin.PcdImageFile-class>`_.

The PcdImageFile Class
----------------------

**PcdImageFile** (class) [`# <#PIL.PcdImagePlugin.PcdImageFile-class>`_]
