==============================
The PIL.JpegImagePlugin Module
==============================

The PIL.JpegImagePlugin Module
==============================

**JpegImageFile** (class)
[`# <#PIL.JpegImagePlugin.JpegImageFile-class>`_]
    Image plugin for JPEG and JFIF images.

    For more information about this class, see `*The JpegImageFile
    Class* <#PIL.JpegImagePlugin.JpegImageFile-class>`_.

The JpegImageFile Class
-----------------------

**JpegImageFile** (class)
[`# <#PIL.JpegImagePlugin.JpegImageFile-class>`_]
