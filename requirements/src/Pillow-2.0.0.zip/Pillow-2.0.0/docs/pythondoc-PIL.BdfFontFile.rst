==========================
The PIL.BdfFontFile Module
==========================

The PIL.BdfFontFile Module
==========================

**BdfFontFile(fp)** (class) [`# <#PIL.BdfFontFile.BdfFontFile-class>`_]
    Font file plugin for the X11 BDF format.

    For more information about this class, see `*The BdfFontFile
    Class* <#PIL.BdfFontFile.BdfFontFile-class>`_.

The BdfFontFile Class
---------------------

**BdfFontFile(fp)** (class) [`# <#PIL.BdfFontFile.BdfFontFile-class>`_]
