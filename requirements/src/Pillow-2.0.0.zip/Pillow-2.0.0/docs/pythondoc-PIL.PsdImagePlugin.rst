=============================
The PIL.PsdImagePlugin Module
=============================

The PIL.PsdImagePlugin Module
=============================

**PsdImageFile** (class) [`# <#PIL.PsdImagePlugin.PsdImageFile-class>`_]
    Image plugin for Photoshop images.

    For more information about this class, see `*The PsdImageFile
    Class* <#PIL.PsdImagePlugin.PsdImageFile-class>`_.

The PsdImageFile Class
----------------------

**PsdImageFile** (class) [`# <#PIL.PsdImagePlugin.PsdImageFile-class>`_]
