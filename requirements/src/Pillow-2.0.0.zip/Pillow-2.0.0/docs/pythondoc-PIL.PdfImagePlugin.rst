=============================
The PIL.PdfImagePlugin Module
=============================

The PIL.PdfImagePlugin Module
=============================

Module Contents
---------------

**\_save(im, fp, filename)** [`# <#PIL.PdfImagePlugin._save-function>`_]
