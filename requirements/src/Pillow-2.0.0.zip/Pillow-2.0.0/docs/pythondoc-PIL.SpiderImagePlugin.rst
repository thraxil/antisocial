================================
The PIL.SpiderImagePlugin Module
================================

The PIL.SpiderImagePlugin Module
================================

Image plugin for the Spider image format. This format is is used by the
SPIDER software, in processing image data from electron microscopy and
tomography.

Module Contents
---------------

**SpiderImageFile** (class)
[`# <#PIL.SpiderImagePlugin.SpiderImageFile-class>`_]
    Image plugin for the SPIDER format.

    For more information about this class, see `*The SpiderImageFile
    Class* <#PIL.SpiderImagePlugin.SpiderImageFile-class>`_.

The SpiderImageFile Class
-------------------------

**SpiderImageFile** (class)
[`# <#PIL.SpiderImagePlugin.SpiderImageFile-class>`_]
    Image plugin for the SPIDER format.

