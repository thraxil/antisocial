=============================
The PIL.GifImagePlugin Module
=============================

The PIL.GifImagePlugin Module
=============================

**GifImageFile** (class) [`# <#PIL.GifImagePlugin.GifImageFile-class>`_]
    Image plugin for GIF images.

    For more information about this class, see `*The GifImageFile
    Class* <#PIL.GifImagePlugin.GifImageFile-class>`_.

The GifImageFile Class
----------------------

**GifImageFile** (class) [`# <#PIL.GifImagePlugin.GifImageFile-class>`_]
