==============================
The PIL.PalmImagePlugin Module
==============================

The PIL.PalmImagePlugin Module
==============================

Module Contents
---------------

**\_save(im, fp, filename, check=0)**
[`# <#PIL.PalmImagePlugin._save-function>`_]
