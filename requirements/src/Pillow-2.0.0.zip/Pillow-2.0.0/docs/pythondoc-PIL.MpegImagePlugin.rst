==============================
The PIL.MpegImagePlugin Module
==============================

The PIL.MpegImagePlugin Module
==============================

**MpegImageFile** (class)
[`# <#PIL.MpegImagePlugin.MpegImageFile-class>`_]
    Image plugin for MPEG streams.

    For more information about this class, see `*The MpegImageFile
    Class* <#PIL.MpegImagePlugin.MpegImageFile-class>`_.

The MpegImageFile Class
-----------------------

**MpegImageFile** (class)
[`# <#PIL.MpegImagePlugin.MpegImageFile-class>`_]
