=============================
The PIL.CurImagePlugin Module
=============================

The PIL.CurImagePlugin Module
=============================

**CurImageFile** (class) [`# <#PIL.CurImagePlugin.CurImageFile-class>`_]
    Image plugin for Windows Cursor files.

    For more information about this class, see `*The CurImageFile
    Class* <#PIL.CurImagePlugin.CurImageFile-class>`_.

The CurImageFile Class
----------------------

**CurImageFile** (class) [`# <#PIL.CurImagePlugin.CurImageFile-class>`_]
