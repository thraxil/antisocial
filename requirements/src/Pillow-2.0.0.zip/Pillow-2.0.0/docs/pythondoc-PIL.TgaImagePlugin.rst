=============================
The PIL.TgaImagePlugin Module
=============================

The PIL.TgaImagePlugin Module
=============================

**TgaImageFile** (class) [`# <#PIL.TgaImagePlugin.TgaImageFile-class>`_]
    Image plugin for Targa files.

    For more information about this class, see `*The TgaImageFile
    Class* <#PIL.TgaImagePlugin.TgaImageFile-class>`_.

The TgaImageFile Class
----------------------

**TgaImageFile** (class) [`# <#PIL.TgaImagePlugin.TgaImageFile-class>`_]
