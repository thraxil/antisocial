=========================
The PIL.ImageColor Module
=========================

The PIL.ImageColor Module
=========================

**getrgb(color)** [`# <#PIL.ImageColor.getrgb-function>`_]

    *color*
    Returns:
    Raises **ValueError**:

