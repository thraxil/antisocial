===============================
The PIL.GimpGradientFile Module
===============================

The PIL.GimpGradientFile Module
===============================

**GimpGradientFile(fp)** (class)
[`# <#PIL.GimpGradientFile.GimpGradientFile-class>`_]
    File handler for GIMP's gradient format.

    For more information about this class, see `*The GimpGradientFile
    Class* <#PIL.GimpGradientFile.GimpGradientFile-class>`_.

The GimpGradientFile Class
--------------------------

**GimpGradientFile(fp)** (class)
[`# <#PIL.GimpGradientFile.GimpGradientFile-class>`_]
