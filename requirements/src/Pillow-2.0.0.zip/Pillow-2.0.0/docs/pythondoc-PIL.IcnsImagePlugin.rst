==============================
The PIL.IcnsImagePlugin Module
==============================

The PIL.IcnsImagePlugin Module
==============================

**IcnsImageFile** (class)
[`# <#PIL.IcnsImagePlugin.IcnsImageFile-class>`_]
    Image plugin for Mac OS icons.

    For more information about this class, see `*The IcnsImageFile
    Class* <#PIL.IcnsImagePlugin.IcnsImageFile-class>`_.

The IcnsImageFile Class
-----------------------

**IcnsImageFile** (class)
[`# <#PIL.IcnsImagePlugin.IcnsImageFile-class>`_]
