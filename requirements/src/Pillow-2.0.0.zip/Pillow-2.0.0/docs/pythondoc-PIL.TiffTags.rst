=======================
The PIL.TiffTags Module
=======================

The PIL.TiffTags Module
=======================

Module Contents
---------------

**TAGS** (variable) [`# <#PIL.TiffTags.TAGS-variable>`_]
**TYPES** (variable) [`# <#PIL.TiffTags.TYPES-variable>`_]
