======================
The PIL.ImageGL Module
======================

The PIL.ImageGL Module
======================

Module Contents
---------------

**TextureFactory** (class) [`# <#PIL.ImageGL.TextureFactory-class>`_]
    Texture factory.

    For more information about this class, see `*The TextureFactory
    Class* <#PIL.ImageGL.TextureFactory-class>`_.

The TextureFactory Class
------------------------

**TextureFactory** (class) [`# <#PIL.ImageGL.TextureFactory-class>`_]
