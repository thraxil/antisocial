=============================
The PIL.FpxImagePlugin Module
=============================

The PIL.FpxImagePlugin Module
=============================

**FpxImageFile** (class) [`# <#PIL.FpxImagePlugin.FpxImageFile-class>`_]
    Image plugin for the FlashPix images.

    For more information about this class, see `*The FpxImageFile
    Class* <#PIL.FpxImagePlugin.FpxImageFile-class>`_.

The FpxImageFile Class
----------------------

**FpxImageFile** (class) [`# <#PIL.FpxImagePlugin.FpxImageFile-class>`_]
