=============================
The PIL.EpsImagePlugin Module
=============================

The PIL.EpsImagePlugin Module
=============================

**EpsImageFile** (class) [`# <#PIL.EpsImagePlugin.EpsImageFile-class>`_]
    Image plugin for Encapsulated Postscript.

    For more information about this class, see `*The EpsImageFile
    Class* <#PIL.EpsImagePlugin.EpsImageFile-class>`_.

The EpsImageFile Class
----------------------

**EpsImageFile** (class) [`# <#PIL.EpsImagePlugin.EpsImageFile-class>`_]
