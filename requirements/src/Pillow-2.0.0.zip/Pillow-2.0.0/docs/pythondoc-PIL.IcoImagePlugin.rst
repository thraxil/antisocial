=============================
The PIL.IcoImagePlugin Module
=============================

The PIL.IcoImagePlugin Module
=============================

**IcoImageFile** (class) [`# <#PIL.IcoImagePlugin.IcoImageFile-class>`_]
    Image plugin for Windows Icon files.

    For more information about this class, see `*The IcoImageFile
    Class* <#PIL.IcoImagePlugin.IcoImageFile-class>`_.

The IcoImageFile Class
----------------------

**IcoImageFile** (class) [`# <#PIL.IcoImagePlugin.IcoImageFile-class>`_]
