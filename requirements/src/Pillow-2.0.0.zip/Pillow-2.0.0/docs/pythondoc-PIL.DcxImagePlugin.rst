=============================
The PIL.DcxImagePlugin Module
=============================

The PIL.DcxImagePlugin Module
=============================

**DcxImageFile** (class) [`# <#PIL.DcxImagePlugin.DcxImageFile-class>`_]
    Image plugin for the Intel DCX format.

    For more information about this class, see `*The DcxImageFile
    Class* <#PIL.DcxImagePlugin.DcxImageFile-class>`_.

The DcxImageFile Class
----------------------

**DcxImageFile** (class) [`# <#PIL.DcxImagePlugin.DcxImageFile-class>`_]
