=============================
The PIL.XpmImagePlugin Module
=============================

The PIL.XpmImagePlugin Module
=============================

**XpmImageFile** (class) [`# <#PIL.XpmImagePlugin.XpmImageFile-class>`_]
    Image plugin for X11 pixel maps.

    For more information about this class, see `*The XpmImageFile
    Class* <#PIL.XpmImagePlugin.XpmImageFile-class>`_.

The XpmImageFile Class
----------------------

**XpmImageFile** (class) [`# <#PIL.XpmImagePlugin.XpmImageFile-class>`_]
