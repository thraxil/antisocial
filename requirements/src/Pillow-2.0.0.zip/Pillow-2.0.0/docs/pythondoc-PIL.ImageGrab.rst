========================
The PIL.ImageGrab Module
========================

The PIL.ImageGrab Module
========================

(New in 1.1.3) The **ImageGrab** module can be used to copy the contents
of the screen to a PIL image memory.

The current version works on Windows only.

Module Contents
---------------

**grab(bbox=None)** [`# <#PIL.ImageGrab.grab-function>`_]

    *bbox*
    Returns:

**grabclipboard()** [`# <#PIL.ImageGrab.grabclipboard-function>`_]

    Returns:

