===========================
The PIL.ImagePalette Module
===========================

The PIL.ImagePalette Module
===========================

**ImagePalette(mode="RGB", palette=None)** (class)
[`# <#PIL.ImagePalette.ImagePalette-class>`_]
    Colour palette wrapper for palette mapped images.

    For more information about this class, see `*The ImagePalette
    Class* <#PIL.ImagePalette.ImagePalette-class>`_.

The ImagePalette Class
----------------------

**ImagePalette(mode="RGB", palette=None)** (class)
[`# <#PIL.ImagePalette.ImagePalette-class>`_]
