===============================
The PIL.PixarImagePlugin Module
===============================

The PIL.PixarImagePlugin Module
===============================

**PixarImageFile** (class)
[`# <#PIL.PixarImagePlugin.PixarImageFile-class>`_]
    Image plugin for PIXAR raster images.

    For more information about this class, see `*The PixarImageFile
    Class* <#PIL.PixarImagePlugin.PixarImageFile-class>`_.

The PixarImageFile Class
------------------------

**PixarImageFile** (class)
[`# <#PIL.PixarImagePlugin.PixarImageFile-class>`_]
