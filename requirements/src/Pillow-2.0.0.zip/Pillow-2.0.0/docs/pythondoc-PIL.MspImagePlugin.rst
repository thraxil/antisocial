=============================
The PIL.MspImagePlugin Module
=============================

The PIL.MspImagePlugin Module
=============================

**MspImageFile** (class) [`# <#PIL.MspImagePlugin.MspImageFile-class>`_]
    Image plugin for Windows MSP images.

    For more information about this class, see `*The MspImageFile
    Class* <#PIL.MspImagePlugin.MspImageFile-class>`_.

The MspImageFile Class
----------------------

**MspImageFile** (class) [`# <#PIL.MspImagePlugin.MspImageFile-class>`_]
