=============================
The PIL.BmpImagePlugin Module
=============================

The PIL.BmpImagePlugin Module
=============================

**BmpImageFile** (class) [`# <#PIL.BmpImagePlugin.BmpImageFile-class>`_]
    Image plugin for the Windows BMP format.

    For more information about this class, see `*The BmpImageFile
    Class* <#PIL.BmpImagePlugin.BmpImageFile-class>`_.

The BmpImageFile Class
----------------------

**BmpImageFile** (class) [`# <#PIL.BmpImagePlugin.BmpImageFile-class>`_]
