Minimalistic PIL test framework.

Test scripts are named "test_xxx" and are supposed to output "ok".
That's it.
