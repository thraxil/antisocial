from distutils.version import StrictVersion


VERSION = StrictVersion('2.0.3')

