==========================================
 celery.security.serialization
==========================================

.. contents::
    :local:
.. currentmodule:: celery.security.serialization

.. automodule:: celery.security.serialization
    :members:
    :undoc-members:
