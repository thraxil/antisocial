==============================
 celery.utils.timer2
==============================

.. contents::
    :local:
.. currentmodule:: celery.utils.timer2

.. automodule:: celery.utils.timer2
    :members:
    :undoc-members:
