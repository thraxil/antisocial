=====================================
 celery.backends.base
=====================================

.. contents::
    :local:
.. currentmodule:: celery.backends.base

.. automodule:: celery.backends.base
    :members:
    :undoc-members:


