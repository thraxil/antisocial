===================================
 celery.app.task
===================================

.. contents::
    :local:
.. currentmodule:: celery.app.task

.. automodule:: celery.app.task
    :members: Task, Context, TaskType
