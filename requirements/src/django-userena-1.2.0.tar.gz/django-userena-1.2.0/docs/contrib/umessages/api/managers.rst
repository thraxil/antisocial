.. _messages-api-managers:

Managers
========

.. automodule:: userena.contrib.umessages.managers

MessageManager
--------------

.. autoclass:: userena.contrib.umessages.managers.MessageManager
   :members:
