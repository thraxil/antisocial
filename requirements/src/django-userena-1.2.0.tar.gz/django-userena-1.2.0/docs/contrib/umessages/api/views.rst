.. _messages-api-views:

Views
=====

.. automodule:: userena.contrib.umessages.views

message_list
------------

.. autofunction:: userena.contrib.umessages.views.message_list

message_detail
--------------

.. autofunction:: userena.contrib.umessages.views.message_detail

message_compose
---------------

.. autofunction:: userena.contrib.umessages.views.message_compose

message_remove
--------------

.. autofunction:: userena.contrib.umessages.views.message_remove
