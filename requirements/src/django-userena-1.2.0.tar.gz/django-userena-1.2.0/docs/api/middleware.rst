.. _api-middleware:

Middleware
==========

.. automodule:: userena.middleware

Return to :ref:`api`

UserenaLocaleMiddleware
-----------------------

.. autoclass:: userena.middleware.UserenaLocaleMiddleware
   :members:
