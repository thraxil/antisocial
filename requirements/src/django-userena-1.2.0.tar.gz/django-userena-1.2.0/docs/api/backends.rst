.. _api-backends:

Backends
========

.. automodule:: userena.backends

Return to :ref:`api`.

.. autoclass:: userena.backends.UserenaAuthenticationBackend
   :members:
