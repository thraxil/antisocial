.. _api-decorators:

Decorators
==========

.. automodule:: userena.decorators

Return to :ref:`api`.

secure_required
---------------

.. autofunction:: userena.decorators.secure_required
