.. _index:

=====================================================
 django-guardian - per object permissions for Django
=====================================================

:Date: |today|

**Documentation**:

.. image:: https://secure.travis-ci.org/lukaszb/django-guardian.png?branch=master
  :target: http://travis-ci.org/lukaszb/django-guardian

.. toctree::
    :maxdepth: 2

    overview
    installation
    configuration
    userguide/index
    api/index
    develop/index
    license


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

