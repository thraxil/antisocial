.. _api-management-commands:

Management commands
===================

.. command:: clean_orphan_obj_perms

.. autoclass:: guardian.management.commands.clean_orphan_obj_perms.Command

