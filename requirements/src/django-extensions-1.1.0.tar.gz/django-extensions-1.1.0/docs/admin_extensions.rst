Current Admin Extensions
========================

:synopsis: Current Field Extensions


* *ForeignKeyAutocompleteAdmin* - ForeignKeyAutocompleteAdmin will enable the
  admin app to show ForeignKey fields with an search input field. The search
  field is rendered by the ForeignKeySearchInput form widget and uses jQuery
  to do configureable autocompletion.

You can watch a small demo at Flickr_.


.. _Flickr: http://www.flickr.com/photos/jannis/3246408003/