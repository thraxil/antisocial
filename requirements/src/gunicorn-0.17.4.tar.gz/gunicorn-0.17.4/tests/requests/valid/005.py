request = {
    "method": "GET",
    "uri": uri("/forums/1/topics/2375?page=1#posts-17408"),
    "version": (1, 1),
    "headers": [],
    "body": b""
}
