from staticmedia.base import (
    get_mount_points, resolve, url, path, serve,
    StaticMediaNotFound,
)
