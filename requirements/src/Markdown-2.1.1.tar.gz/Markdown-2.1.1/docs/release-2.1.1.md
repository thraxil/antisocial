Python-Markdown 2.1.1 Release Notes
===================================

Python-Markdown 2.1.1 is a bug-fix release. No new features have been added.
Most notably, a bug which caused raw HTML paring to run __very__ slowly has
been fixed along with a few bugs which caused the parser to raise exceptions
while parsing. For a full list of changes, see the git log.
