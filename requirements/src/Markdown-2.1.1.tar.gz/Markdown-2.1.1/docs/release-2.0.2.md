Python-Markdown 2.0.2 Release Notes
===================================

Python-Markdown 2.0.2 is a bug-fix release. No new features have been added.
Most notably, the setup script has been updated to include a dependency on 
ElementTree on older versions of Python (< 2.5). There have also been a few 
fixes for minor parsing bugs in some edge cases. For a full list of changes, 
see the git log.

