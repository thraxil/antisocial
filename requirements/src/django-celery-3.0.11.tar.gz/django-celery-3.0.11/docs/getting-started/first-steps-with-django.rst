=========================
 First steps with Django
=========================

This document has been moved into the main Celery documentation,
you can find it at:;

    http://celery.github.com/celery/django/first-steps-with-django.html
