============================
 App - djcelery.app
============================

.. contents::
    :local:
.. currentmodule:: djcelery.app

.. automodule:: djcelery.app
    :members:
    :undoc-members:
